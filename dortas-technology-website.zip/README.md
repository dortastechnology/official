# DORTAS TECHNOLOGY website

## Free publishing with GitHub Pages
1. Create a GitHub account at https://github.com/
2. Create a new public repository named `dortas-technology` (or `YOURUSERNAME.github.io`).
3. Upload `index.html`.
4. Repository Settings → Pages → Deploy from a branch → `main` → `/root`.
5. Save. GitHub will provide the live URL.

## Before publishing
- Replace the placeholder product copy with verified product specifications.
- Replace `sales@dortastechnology.com` with your real business email.
- Add your real logo/product photos.
- Connect the contact form to Formspree, Netlify Forms, or your own backend if you want messages to be received.
- Add only certifications and regulatory claims that your company actually holds.
